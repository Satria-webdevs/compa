<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> <?php echo e($breadcrumb); ?> <?php $__env->endSlot(); ?>

    <div class="d-flex bg-white rounded-4 shadow-sm p-4 mb-4">
        <!-- button form add data -->
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary rounded-pill py-2 px-4 me-md-2">
            <i class="ti ti-plus me-2"></i> Add Product
        </a>
        <!-- form pencarian -->
        <form action="<?php echo e(route('products.index')); ?>" method="GET" class="ms-auto">
            <div class="input-group">
                <input type="text" name="search" class="form-control rounded-start-pill py-2 px-4" value="<?php echo e(request('search')); ?>" placeholder="Search product ..." autocomplete="off">
                <button class="btn btn-primary rounded-end-pill py-2 px-3" type="submit">Search</button>
            </div>
        </form>
    </div>

    <div class="mb-4">
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <!-- jika data ada, tampilkan data -->
            <div class="d-flex bg-white rounded-4 shadow-sm p-2 mb-3">
                <div class="flex-shrink-0 p-3">
                    <img src="<?php echo e(asset('/storage/products/'.$product->image)); ?>" class="border img-fluid rounded-4 shadow-sm" alt="Images" width="200">
                </div>
                <div class="p-4 flex-grow-1">
                    <h5><?php echo e($product->title); ?></h5>
                    <p class="text-muted"><i class="ti ti-tag me-1"></i> <?php echo e($product->category); ?></p>
                    <p class="text-success fw-medium"><?php echo e('Rp ' . number_format($product->price, 0, '', '.')); ?></p>
                </div>
                <div class="p-4">
                    <div class="d-flex flex-column flex-lg-row">
                        <!-- button form detail data -->
                        <a href="<?php echo e(route('products.show', $product->id)); ?>" class="btn btn-primary btn-sm rounded-pill px-3 me-2 mb-2 mb-lg-0"> Detail </a>
                        <!-- button form edit data -->
                        <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-success btn-sm rounded-pill px-3 me-2 mb-2 mb-lg-0"> Edit </a>
                        <!-- button modal hapus data -->
                        <button type="button" class="btn btn-danger btn-sm rounded-pill px-3" data-bs-toggle="modal" data-bs-target="#modalDelete<?php echo e($product->id); ?>"> Delete </button>
                    </div>
                </div>
            </div>

            <!-- Modal hapus data -->
            <div class="modal fade" id="modalDelete<?php echo e($product->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modalDeleteLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                <i class="ti ti-trash me-2"></i> Delete Product
                            </h1>
                        </div>
                        <div class="modal-body">
                            <!-- informasi data yang akan dihapus -->
                            <p class="mb-2">
                                Are you sure to delete <span class="fw-medium mb-2"><?php echo e($product->title); ?></span>?
                            </p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary rounded-pill px-3" data-bs-dismiss="modal">Cancel</button>
                            <!-- button hapus data -->
                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger rounded-pill px-3"> Yes, delete it! </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <!-- jika data tidak ada, tampilkan pesan data tidak tersedia -->
            <div class="alert alert-primary d-flex align-items-center" role="alert">
                <i class="ti ti-info-circle me-2"></i>
                <div>No data available.</div>
            </div>
        <?php endif; ?>
    </div>

    <!-- pagination -->
    <div class="pagination-links mb-5"><?php echo e($products->links()); ?></div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH D:\laragon\www\Pustaka-Koding\Project-Laravel\Laravel-11\aplikasi-crud-laravel11\resources\views/products/index.blade.php ENDPATH**/ ?>