<div class="ms-5 ms-lg-0 pt-lg-3">
    <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="https://pustakakoding.com/" class="text-dark text-decoration-none"><i class="ti ti-home fs-5"></i></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>" class="text-dark text-decoration-none">Products</a></li>
            <li class="breadcrumb-item" aria-current="page"><?php echo e($slot); ?></li>
        </ol>
    </nav>
</div><?php /**PATH D:\laragon\www\Pustaka-Koding\Project-Laravel\Laravel-11\aplikasi-crud-laravel11\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>