<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('breadcrumb', null, []); ?> <?php echo e($breadcrumb); ?> <?php $__env->endSlot(); ?>

    <div class="bg-white rounded-4 shadow-sm p-4 mb-5">
        <!-- judul form -->
        <div class="alert alert-primary rounded-4 mb-5" role="alert">
            <i class="ti ti-list fs-5 align-text-top me-2"></i> Detail Product
        </div>
        <!-- detail data -->
        <div class="row flex-lg-row align-items-center g-5">
            <div class="col-lg-3">
                <img src="<?php echo e(asset('/storage/products/'.$product->image)); ?>" class="d-block mx-lg-auto img-fluid rounded-4 shadow-sm" alt="Images" loading="lazy">
            </div>
            <div class="col-lg-9">
                <h4><?php echo e($product->title); ?></h4>
                <p class="text-muted"><i class="ti ti-tag me-1"></i> <?php echo e($product->category); ?></p>
                <p><?php echo $product->description; ?></p>
                <p class="text-success fw-medium"><?php echo e('Rp ' . number_format($product->price, 0, '', '.')); ?></p>
            </div>
        </div>
        <div class="pt-4 pb-2 mt-5 border-top">
            <div class="d-grid gap-3 d-sm-flex justify-content-md-start pt-1">
                <!-- button kembali ke halaman index -->
                <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary rounded-pill py-2 px-4">Close</a>
            </div>
        </div>
    </div>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Pustaka-Koding\Project-Laravel\Laravel-11\aplikasi-crud-laravel11\resources\views/products/show.blade.php ENDPATH**/ ?>