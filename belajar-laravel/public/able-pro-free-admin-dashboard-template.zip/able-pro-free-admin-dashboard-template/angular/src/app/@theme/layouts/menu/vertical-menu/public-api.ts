export * from './vertical-menu.component';
