import { Outlet } from 'react-router-dom';

// ==============================|| MINIMAL LAYOUT ||============================== //

const CommonLayout = () => {
  return <Outlet />;
};

export default CommonLayout;
